%Set sample rate and duration
rate = 1000; %scan rate in rate/sec
duration = 5; %duration of acquisition

%locate device, should be Dev2
devices = daq.getDevices
nidaq = devices(10); %get Dev2 device

%set analog channels to record voltage, 2 channels here
s = daq.createSession('ni');
addAnalogInputChannel(s,'Dev2', 0, 'Voltage');
addAnalogInputChannel(s,'Dev2', 1, 'Voltage');

%rate and duration properties
s.Rate = rate; %set session rate
s.DurationInSeconds = duration;

%start the session in foreground
[data, time] = s.startForeground; %start session in foreground

%plot data vs time, two channels make two lines
plot(time,data); xlabel('Time (secs)'); ylabel('Voltage');

