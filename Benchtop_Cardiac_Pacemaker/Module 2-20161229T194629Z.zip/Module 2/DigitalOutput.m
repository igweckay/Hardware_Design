% daqhwinfo
% info=daqhwinfo('nidaq');
% info.InstalledBoardIds

% %DIGITAL OUTPUT
% dio = digitalio('nidaq', 'Dev13');
% hline = addline(dio, 0:4, 0, 'Out');
% for i = 1:250;
%     putvalue(dio, [1 0 0 0 0]);
%     pause(.02)
%     putvalue(dio, [0 1 0 0 0]);
%     pause(.02)
% end

%DIGITAL INPUT
dio = digitalio('nidaq', 'Dev13');
hline = addline(dio, 0:1, 1, 'In');

 for i = 1:250;
    valuez = getvalue(dio.Line(1));
    if valuez == 1;
        disp('high')
%     else
%         disp('low')
    end
    pause(.02)
 end
 

%value = getvalue(dio);
