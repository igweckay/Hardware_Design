function rawSignal = RecordSignal_DUMMY(sampleRate,duration)

% Returns a 10Hz sine wave with the specified sample rate and duration.
%
% rawSignal = RecordSignal_DUMMY(ai,sampleRate,duration)
%
% This is a "dummy" version of the function RecordSignal to be used during
% the Bioinstrumentation Module II.1 pre-lab. It has the same inputs and
% outputs as RecordSignal, but will return a 10Hz sine wave instead of a
% recording from the NIDAQ.
%
% INPUTS:

% -sampleRate is a scalar indicating the desired sampling rate of the 
% recording in Hz.
% -duration is a scalar indicating the desired duration of the recording in
% seconds.
%
% OUTPUTS:
% -rawSignal is a column vector of length sampleRate*duration.
%
% Created 10/9/2013 by DJ.

nT = sampleRate*duration;
t = (1:nT)/sampleRate;
rawSignal = sin(10*2*pi*t);