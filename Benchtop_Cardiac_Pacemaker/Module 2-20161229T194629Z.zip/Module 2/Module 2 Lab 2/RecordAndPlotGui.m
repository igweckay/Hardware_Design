function varargout = RecordAndPlotGui(varargin)
% RECORDANDPLOTGUI MATLAB code for RecordAndPlotGui.fig
%      RECORDANDPLOTGUI, by itself, creates a new RECORDANDPLOTGUI or raises the existing
%      singleton*.
%
%      H = RECORDANDPLOTGUI returns the handle to a new RECORDANDPLOTGUI or the handle to
%      the existing singleton*.
%
%      RECORDANDPLOTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RECORDANDPLOTGUI.M with the given input arguments.
%
%      RECORDANDPLOTGUI('Property','Value',...) creates a new RECORDANDPLOTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RecordAndPlotGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RecordAndPlotGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RecordAndPlotGui

% Last Modified by GUIDE v2.5 27-Feb-2015 16:40:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RecordAndPlotGui_OpeningFcn, ...
                   'gui_OutputFcn',  @RecordAndPlotGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RecordAndPlotGui is made visible.
function RecordAndPlotGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RecordAndPlotGui (see VARARGIN)

% Create analog input object                                added
clc
% Choose default command line output for RecordAndPlotGui
handles.output = hObject;

% global stopButton
% stopButton=0;
% handles.stopButton=stopButton;

ai = analoginput('nidaq','Dev3');           %FOR PART 1 OF LAB%%%%%%%%%
chans = addchannel(ai,[1 3]);           %FOR PART 1 OF LAB%%%%%%%%%

% handles.flag_val = flag_val;
handles.ai = ai;
handles.chans = chans;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RecordAndPlotGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = RecordAndPlotGui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in button_record.
function button_record_Callback(hObject, eventdata, handles)
% hObject    handle to button_record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ai = handles.ai;
sampleRate = str2double(get(handles.edit_samplerate, 'String'));            %added at step 8
duration = str2double(get(handles.edit_duration, 'String'));          %added at step 8
%flag_val = handles.flag_val;
set(handles.text_status, 'String', 'Recording...');          %added at step 10

%[rawSignal,t] = RecordSignal(handles.ai, sampleRate, duration);        %added at step 8    %FOR PART 1 OF LAB, change RecordSignal_Dummy to RecordSignal%%%%%%%%%
set(ai,'SamplesPerTrigger',sampleRate*duration); %set total samples
set(ai,'TriggerType','Immediate'); %set trigger to immediate

%  while handles.stopButton == 0
%     start(ai)
%     disp('recording signal started')
%      [rawSignal, t]=getdata(ai);
%      StopButton_Callback(hObject, eventdata, handles);
%      
%  end
start(ai)
[rawSignal,t] = getdata(ai);
% while flag_val == 0
%     a=flag_val
%         start(ai) % trigger start
%         disp('recording started again');
%         [rawSignal,t] = getdata(ai);
%     
% end
%set(handles.text_status, 'String', 'Recording Completed!');          %added at step 10
stop(ai)
filename = sprintf('RawSignal%dHz%dsec.mat',sampleRate, duration);
save(filename, 'rawSignal', 'sampleRate', 'duration','t')

handles.t = t;
%handles.flag_val = flag_val;
handles.rawSignal = rawSignal;          %added at step 9
handles.sampleRate = sampleRate;          %added at step 9
handles.duration = duration;          %added at step 9
handles.filename = filename;          %added at step 9
guidata(hObject, handles);          %added at step 9

% --- Executes on button press in button_plot.
function button_plot_Callback(hObject, eventdata, handles)
% hObject    handle to button_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

axes(handles.axes_signal);          %added at step 11
%PlotSignal (handles.rawSignal, handles.sampleRate, handles.duration);
plot(handles.t,handles.rawSignal); 
% figname='mod2_2_challenge1Hz.m'; %not sure if png will work...
% savefig(figname)

a=handles.rawSignal(:,1);
b=handles.t;
A = handles.rawSignal
B = handles.t
spikeT=[];

for i=1:length(a)
if a(i) > 0 && a(i-1)<0     
    
    timeVal = b(i);  
    spikeT = [spikeT timeVal];
    
    
end

end
delSpike=diff(spikeT);
btbHR=60./delSpike;
avgHR= (mean(btbHR))
HRstd=std(btbHR)

set(handles.averageHR, 'String', (avgHR));
set(handles.stDev, 'String', (HRstd));


function edit_samplerate_Callback(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_samplerate as text
%        str2double(get(hObject,'String')) returns contents of edit_samplerate as a double


% --- Executes during object creation, after setting all properties.
function edit_samplerate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_duration_Callback(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% Hints: get(hObject,'String') returns contents of edit_duration as text
%        str2double(get(hObject,'String')) returns contents of edit_duration as a double


% --- Executes during object creation, after setting all properties.
function edit_duration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');

%function [filename] = SaveSignal(rawSignal, sampleRate, duration)


%function PlotSignal(rawSignal, sampleRate, duration)

% numRawSignal = length(rawSignal);
% x = (1/sampleRate):(1/sampleRate):(numRawSignal/sampleRate);
% plot(x, rawSignal);
% grid on
% plotName = ['Raw Signal Sampled at ',num2str(sampleRate),'Hz for',num2str(duration),'s'];
% title(plotName);
% xlabel('Time (s)');
% ylabel('Signal (V)');
end

% --- Executes on button press in StopButton.
function StopButton_Callback(hObject, eventdata, handles)
% hObject    handle to StopButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% flag_val = 1;
% handles.flag_val = flag_val;
% disp('stop button pressed')
% guidata(hObject, handles);          %added at step 9
% stopButton=1;
% handles.stopButton=stopButton;


% --- Executes on button press in StopToggle.
function StopToggle_Callback(hObject, eventdata, handles)
% hObject    handle to StopToggle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of StopToggle
% stopTog =get(hObject,'Value')
% if stopTog == 1
%     disp('toggle stop')
%     stop(ai)
% end
