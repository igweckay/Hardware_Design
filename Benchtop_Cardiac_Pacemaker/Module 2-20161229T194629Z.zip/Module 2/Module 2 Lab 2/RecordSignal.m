%RECORD SIGNAL FUNCTION
function [V,t]=RecordSignal(ai,sampleRate,duration)
%sampleRate= scalar, Hz
%duration=scalar, seconds

% T = sampleRate*duration;
% t = (1:T)/sampleRate;
% rawSignal = sin(10*2*pi*t); %column vector of length sampleRate*duration
% 
% file='mod2_1.m';%define filename
% % save(file)

%set(ai,'SampleRate',sampleHz); % set sample rate
set(ai,'SamplesPerTrigger',sampleRate*duration); %set total samples
set(ai,'TriggerType','Immediate'); %set trigger to immediate

start(ai) % trigger start

[V,t] = getdata(ai);

filez='mod2_ECG20000.mat';%define filename
save(filez,'t','V')
end


