daqhwinfo
info=daqhwinfo('nidaq');
info.InstalledBoardIds

duration=10;%acquire for 5 seconds
sampleHz=1000; %sample rate
ai=analoginput('nidaq', 'Dev3'); %REPLACE DEVICEID with actual device ID
chan1=addchannel(ai,1);
chan2=addchannel(ai,3);

set(ai,'SampleRate',sampleHz); % set sample rate
set(ai,'SamplesPerTrigger',sampleHz*duration); %set total samples
set(ai,'TriggerType','Immediate'); %set trigger to immediate

start(ai) % trigger start

[V,t] = getdata(ai);

filez='mod2_labchallenge.mat';%define filename
save(filez,'t','V')

plot(t,V); xlabel('Time (s)');ylabel('Voltage (V)');