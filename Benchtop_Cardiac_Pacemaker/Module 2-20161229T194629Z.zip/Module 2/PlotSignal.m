%PLOTS THE RECORDING
function PlotSignal( rawSignal, sampleRate )

t=length(rawSignal)/sampleRate;
figure; 
plot(t,rawSignal); xlabel('Time (secs)');ylabel('Amplitude (V)')
figname='mod2_plot1.png'; %not sure if png will work...
savefig(figname)

end

