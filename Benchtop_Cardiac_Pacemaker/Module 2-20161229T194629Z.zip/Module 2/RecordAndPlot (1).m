daqhwinfo
info=daqhwinfo('nidaq');
info.InstalledBoardIds

duration=10;%acquire for 10 seconds
sampleHz=8000; %sample rate
ai=analoginput('nidaq', 'Dev13'); %REPLACE DEVICEID with actual device ID
chans=addchannel(ai,0);
set(ai,'SampleRate',sampleHz); % set sample rate
set(ai,'SamplesPerTrigger',sampleHz*duration); %set total samples
start(ai) % trigger start

[rawSignal]=RecordSignal(ai,sampleRate,duration);

PlotSignal(rawSignal,sampleRate)




