% daqhwinfo
% info=daqhwinfo('nidaq');
% info.InstalledBoardIds

duration=5;%acquire for 5 seconds
sampleHz=20000; %sample rate
ai=analoginput('nidaq', 'Dev13'); %REPLACE DEVICEID with actual device ID
chans=addchannel(ai,0);
%chans=addchannel(ai,1);

% set(ai,'SampleRate',sampleHz); % set sample rate
% set(ai,'SamplesPerTrigger',sampleHz*duration); %set total samples
% set(ai,'TriggerType','Immediate'); %set trigger to immediate
% 
% start(ai) % trigger start
% 
% [V,t] = getdata(ai);

%filez='mod2_ECG20000.mat';%define filename
%save(filez,'t','V')

%figure(1)
%plot(t,V); xlabel('Time (s)');ylabel('Voltage (V)');title('ECG - 20000Hz');
% figname='mod2_plot1.fig'; %not sure if png will work...
% savefig(figname)

%%
%[rawSignal]=RecordSignal(sampleHz,duration);
%PlotSignal(rawSignal,sampleHz)

bytes = [1 2 4 6 58 565]*180;
samp = [20 50 100 200 2000 20000];
y = 250;

figure(2)
hold on
plot(samp, bytes,'*-r');xlabel('Sample Rate (Hz)');ylabel('File Size');title('File Size vs Sample Rate');
plot(0:10:20000,250)
hold off

