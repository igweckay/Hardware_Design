%% Module II: Electrogram Digitization & Processing
%
%% RecordAndPlot
% This script allows the user to set up an analog device, open a channel,
% and pass input parameters of chosen analog device, acquisition duration,
% and sample rate to sample an analog signal with desired parameters

% Discover specifications of acquisition unit
daqhwinfo
info=daqhwinfo('nidaq');
info.InstalledBoardIds

%INPUT PARAMETERS, CHOOSE DEVICE, AND OPEN CHANNEL
duration = 5; %duration of acquisition
sampleHz = 20000; %sample rate
ai = analoginput('nidaq', 'Dev13'); %identified ID is Dev13
chans = addchannel(ai,0); %open analog channel 0

%ACQUIRE ANALOG SIGNAL WITH DESIRED SPECS, SAVE, AND PLOT
[rawSignal] = recordSignal(ai, sampleHz, duration);

%% II.1 Procedure1: EFFECTS OF OVER- AND UNDERSAMPLING
% Plot the file size as a function of sample rate
syms y(x)
bytes = [1 2 4 6 58 565]; %file size was determined by looking in folder
samp = [20 50 100 200 2000 20000]; %create array of sample rates for plot
y(x) = 250/(15*60)*5; %250kB file size normalized for 5 second acquisiton
x = 0:10:20000; %x axis vector for plotting 250kB line

figure(2)
hold on
plot(samp, bytes,'*-r');
plot(x,y(x))
xlabel('Sample Rate (Hz)');ylabel('File Size (kB)');
title('File Size vs Sample Rate for 5 Second Acquisition');legend('Acquisitions','Normalized 250kB');
hold off

%% II.1 Procedure 2: DIGITAL OUTPUT
% This script selects a digital acquisition device, opens an output channel with
% physicial lines, and then outputs two signals alternating high and low
% with 180 degree phase.

%DIGITAL OUTPUT
dio = digitalio('nidaq', 'Dev13'); %create digital input/output object
hline = addline(dio, 0:4, 0, 'Out'); %add physical lines to dio as output task

%Output pulse train using dio output lines that outputs HIGH voltage signal
%for 20ms followed by LOW voltage signal for 20ms on line P0.0 while doing
%the reverse order on line P0.1
for i = 1:125; %125 iteration implies 5 seconds
    putvalue(dio, [1 0 0 0 0]); %P0.0 HIGH, P0.1 LOW
    pause(.02); %pulse lasts 20ms
    putvalue(dio, [0 1 0 0 0]); %P0.0 LOW, P0.1 HIGH
    pause(.02); %pulse lasts 20ms
end

%% II.1 Procedure 3: DIGITAL INPUT
% This script selects a digital acquisition device, opens an input channel with
% physicial lines, and samples input signal every 20ms to detect comparator
% output corresponding to QRS peak. Displays 'high' is comparator output is
% positive

%DIGITAL INPUT DEVICE SETUP
dio = digitalio('nidaq', 'Dev13'); %choose digital acq device
hline = addline(dio, 0:1, 1, 'In'); %add physical input lines to port 1

%sample every 20ms for 5 seconds and display 'high' whenever the comparator
%output corresponding to a QRS peak is detected
 for i = 1:250;
    valuez = getvalue(dio.Line(1));
    if valuez == 1;
        disp('high')
    end
    pause(.02)
 end
 
%%  II.1 LAB CHALLENGE
% Records analog inputs from two channels, one containing ECG
% signal and the other containing comparator output. Then save the data and
% plot the figure.

%INPUT PARAMETERS, CHOOSE DEVICE, AND OPEN CHANNELS
duration=10; %set acquisition duration
sampleHz=1000; %sample rate
ai=analoginput('nidaq', 'Dev13'); %choose device
chan1=addchannel(ai,0); %record ECG
chan2=addchannel(ai,1); %record comparator output

%call function for multiple analog channel acquisition
[ rawSignal ] = RecordSignal( ai,sampleHz,duration )

%% II.2: Create the GUI figure (RecordAndPlotGui.m)
%
function varargout = RecordAndPlotGui(varargin)
% RECORDANDPLOTGUI MATLAB code for RecordAndPlotGui.fig
%      RECORDANDPLOTGUI, by itself, creates a new RECORDANDPLOTGUI or raises the existing
%      singleton*.
%
%      H = RECORDANDPLOTGUI returns the handle to a new RECORDANDPLOTGUI or the handle to
%      the existing singleton*.
%
%      RECORDANDPLOTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RECORDANDPLOTGUI.M with the given input arguments.
%
%      RECORDANDPLOTGUI('Property','Value',...) creates a new RECORDANDPLOTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RecordAndPlotGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RecordAndPlotGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RecordAndPlotGui

% Last Modified by GUIDE v2.5 27-Feb-2015 16:40:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RecordAndPlotGui_OpeningFcn, ...
                   'gui_OutputFcn',  @RecordAndPlotGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% Create analog input object 
%
% Creates analog input object from device 3, specifies analog input channels
% and creates global variables for input. 
% Updates handles structure.
%
%--- Executes just before RecordAndPlotGui is made visible.
function RecordAndPlotGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RecordAndPlotGui (see VARARGIN)
                                
clc
% Choose default command line output for RecordAndPlotGui
handles.output = hObject;

ai = analoginput('nidaq','Dev3');           
chans = addchannel(ai,[1 3]);           

handles.ai = ai;            
handles.chans = chans;       
guidata(hObject, handles);          

% UIWAIT makes RecordAndPlotGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%% Get default command line output from handles structure

% --- Outputs from this function are returned to the command line.
function varargout = RecordAndPlotGui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


varargout{1} = handles.output;

%% Create Record button
%
% The following function reads in the parameters from the edit_sampleRate and
% edit_duration text boxes and converts the string data from the Edit Text
% uicontrol objects to numbers. 
%
% Executes on button press in button_record.
function button_record_Callback(hObject, eventdata, handles)
% hObject    handle to button_record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% calls ai variable
ai = handles.ai;            

%reads in the parameters from the edit_sampleRate and edit_duration text
%boxes and converts the string data from the Edit Text uicontrol objects to numbers
sampleRate = str2double(get(handles.edit_samplerate, 'String'));            
duration = str2double(get(handles.edit_duration, 'String'));          

% changes the status box string to 'Recording...'
set(handles.text_status, 'String', 'Recording...');          

%[rawSignal,t] = RecordSignal(handles.ai, sampleRate, duration);
% sets total samples
set(ai,'SamplesPerTrigger',sampleRate*duration); 

% sets trigger to immediate
set(ai,'TriggerType','Immediate'); 

%  while handles.stopButton == 0
%     start(ai)
%     disp('recording signal started')
%      [rawSignal, t]=getdata(ai);
%      StopButton_Callback(hObject, eventdata, handles);
%      
%  end

% starts acquisition
start(ai)

% saves input data to a matrix
[rawSignal,t] = getdata(ai);            

%set(handles.text_status, 'String', 'Recording Completed!');          

% saves filename 
filename = sprintf('RawSignal%dHz%dsec.mat',sampleRate, duration);
save(filename, 'rawSignal', 'sampleRate', 'duration','t')          

% sets time as variable t from matrix created at line 137
handles.t = t;          

% stores the rawSignal, sampleRate, and filename variables in the handles structure 
handles.rawSignal = rawSignal;          
handles.sampleRate = sampleRate;          
handles.duration = duration;          
handles.filename = filename;          
guidata(hObject, handles);          

%% Plot recorded data -- Beat Detection algorithm
%
% The following code plots the recorded data. The beat detection algorithm
% is also included here, as well as the calculation for the average HR and
% HR standard deviation.
%
% Executes on button press in button_plot.
function button_plot_Callback(hObject, eventdata, handles)
% hObject    handle to button_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%specifying the axis to which the data will be plotted and using the variables in the handles structure to plot the recorded signal
axes(handles.axes_signal);      
plot(handles.t,handles.rawSignal); 


%%%%%%%%Beat Detection algorithm%%%%%%%%
a=handles.rawSignal(:,1);           %acquiring the first column from the raw signal output         
b=handles.t;            %assigning time to variable b
A = handles.rawSignal            
B = handles.t
spikeT=[];          %empty vector where the starting timepoint of each consecutive pulse will be saved

for i=1:length(a)               %initiating a for loop for the length of the raw signal, every data point that is acquired
if a(i) > 0 && a(i-1)<=0          %detecting the staring point of the pulse input  
    
    timeVal = b(i);                 %acquiring the time when the pulse occurred
    spikeT = [spikeT timeVal];      %creates a vector to store times when pulses occurred 
end
end

delSpike=diff(spikeT);          %calculating difference between time points
btbHR=60./delSpike;             %calculating the beat to beat HR
avgHR= (mean(btbHR))            %calculating the average HR
HRstd=std(btbHR)            %calculating standard deviation

set(handles.averageHR, 'String', (avgHR));          %setting global variable for average HR
set(handles.stDev, 'String', (HRstd));          %setting global variable for HR standard deviation

%% Default GUI functions
%
% The last part of the GUI code is created by the GUI design environment
% and have not been altered.
%
function edit_samplerate_Callback(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_samplerate as text
%        str2double(get(hObject,'String')) returns contents of edit_samplerate as a double

% --- Executes during object creation, after setting all properties.
function edit_samplerate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit_duration_Callback(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_duration as text
%        str2double(get(hObject,'String')) returns contents of edit_duration as a double

% --- Executes during object creation, after setting all properties.
function edit_duration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%function [filename] = SaveSignal(rawSignal, sampleRate, duration)
