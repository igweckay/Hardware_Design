%% RecordAndPlotGui
%
% Graphic User Interface tool that can acquire, save, and process analog
% and digital data using one or more channels, implemented using MATLAB(R).


%% Create the GUI figure
%
function varargout = RecordAndPlotGui(varargin)
% RECORDANDPLOTGUI MATLAB code for RecordAndPlotGui.fig
%      RECORDANDPLOTGUI, by itself, creates a new RECORDANDPLOTGUI or raises the existing
%      singleton*.
%
%      H = RECORDANDPLOTGUI returns the handle to a new RECORDANDPLOTGUI or the handle to
%      the existing singleton*.
%
%      RECORDANDPLOTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RECORDANDPLOTGUI.M with the given input arguments.
%
%      RECORDANDPLOTGUI('Property','Value',...) creates a new RECORDANDPLOTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RecordAndPlotGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RecordAndPlotGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RecordAndPlotGui

% Last Modified by GUIDE v2.5 27-Feb-2015 16:40:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RecordAndPlotGui_OpeningFcn, ...
                   'gui_OutputFcn',  @RecordAndPlotGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


%% Create analog input object 
%
% Creates analog input object from device 3, specifies analog input channels
% and creates global variables for input. 
% Updates handles structure.
%
%--- Executes just before RecordAndPlotGui is made visible.
function RecordAndPlotGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RecordAndPlotGui (see VARARGIN)
                                
clc
% Choose default command line output for RecordAndPlotGui
handles.output = hObject;

ai = analoginput('nidaq','Dev3');           
chans = addchannel(ai,[1 3]);           

handles.ai = ai;            
handles.chans = chans;       
guidata(hObject, handles);          

% UIWAIT makes RecordAndPlotGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

%% Get default command line output from handles structure

% --- Outputs from this function are returned to the command line.
function varargout = RecordAndPlotGui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


varargout{1} = handles.output;

%% Create Record button
%
% The following function reads in the parameters from the edit_sampleRate and
% edit_duration text boxes and converts the string data from the Edit Text
% uicontrol objects to numbers. 
%
% Executes on button press in button_record.
function button_record_Callback(hObject, eventdata, handles)
% hObject    handle to button_record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% calls ai variable
ai = handles.ai;            

%reads in the parameters from the edit_sampleRate and edit_duration text
%boxes and converts the string data from the Edit Text uicontrol objects to numbers
sampleRate = str2double(get(handles.edit_samplerate, 'String'));            
duration = str2double(get(handles.edit_duration, 'String'));          

% changes the status box string to 'Recording...'
set(handles.text_status, 'String', 'Recording...');          

%[rawSignal,t] = RecordSignal(handles.ai, sampleRate, duration);
% sets total samples
set(ai,'SamplesPerTrigger',sampleRate*duration); 

% sets trigger to immediate
set(ai,'TriggerType','Immediate'); 

%  while handles.stopButton == 0
%     start(ai)
%     disp('recording signal started')
%      [rawSignal, t]=getdata(ai);
%      StopButton_Callback(hObject, eventdata, handles);
%      
%  end

% starts acquisition
start(ai)

% saves input data to a matrix
[rawSignal,t] = getdata(ai);            

%set(handles.text_status, 'String', 'Recording Completed!');          

% saves filename 
filename = sprintf('RawSignal%dHz%dsec.mat',sampleRate, duration);
save(filename, 'rawSignal', 'sampleRate', 'duration','t')          

% sets time as variable t from matrix created at line 137
handles.t = t;          

% stores the rawSignal, sampleRate, and filename variables in the handles structure 
handles.rawSignal = rawSignal;          
handles.sampleRate = sampleRate;          
handles.duration = duration;          
handles.filename = filename;          
guidata(hObject, handles);          

%% Plot recorded data -- Beat Detection algorithm
%
% The following code plots the recorded data. The beat detection algorithm
% is also included here, as well as the calculation for the average HR and
% HR standard deviation.
%
% Executes on button press in button_plot.
function button_plot_Callback(hObject, eventdata, handles)
% hObject    handle to button_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%specifying the axis to which the data will be plotted and using the variables in the handles structure to plot the recorded signal
axes(handles.axes_signal);      
plot(handles.t,handles.rawSignal); 


%%%%%%%%Beat Detection algorithm%%%%%%%%

a=handles.rawSignal(:,1);           %acquiring the first column from the raw signal output         
b=handles.t;            %assigning time to variable b
A = handles.rawSignal            
B = handles.t
spikeT=[];          %empty vector where the starting timepoint of each consecutive pulse will be saved

for i=1:length(a)               %initiating a for loop for the length of the raw signal, every data point that is acquired
if a(i) > 0 && a(i-1)<=0          %detecting the staring point of the pulse input  
    
    timeVal = b(i);                 %acquiring the time when the pulse occurred
    spikeT = [spikeT timeVal];      %creates a vector to store times when pulses occurred
    
    
end

end


delSpike=diff(spikeT);          %calculating difference between time points
btbHR=60./delSpike;             %calculating the beat to beat HR
avgHR= (mean(btbHR))            %calculating the average HR
HRstd=std(btbHR)            %calculating standard deviation

set(handles.averageHR, 'String', (avgHR));          %setting global variable for average HR
set(handles.stDev, 'String', (HRstd));          %setting global variable for HR standard deviation

%% Default GUI functions
%
% The last part of the GUI code is created by the GUI design environment
% and have not been altered.
%
%
function edit_samplerate_Callback(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_samplerate as text
%        str2double(get(hObject,'String')) returns contents of edit_samplerate as a double


% --- Executes during object creation, after setting all properties.
function edit_samplerate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_samplerate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit_duration_Callback(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% Hints: get(hObject,'String') returns contents of edit_duration as text
%        str2double(get(hObject,'String')) returns contents of edit_duration as a double


% --- Executes during object creation, after setting all properties.
function edit_duration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_duration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
%function [filename] = SaveSignal(rawSignal, sampleRate, duration)


