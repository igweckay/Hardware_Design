%RECORD SIGNAL FUNCTION
function [rawSignal]=RecordSignal(sampleRate,duration)
%sampleRate= scalar, Hz
%duration=scalar, seconds

nT = sampleRate*duration;
t = (1:nT)/sampleRate;
rawSignal = sin(10*2*pi*t); %column vector of length sampleRate*duration

file='Insert Filename Here.m';%define filename
save(file,'t','rawSignal')

end


