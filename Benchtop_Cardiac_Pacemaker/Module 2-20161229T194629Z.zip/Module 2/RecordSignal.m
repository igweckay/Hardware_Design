%RECORD SIGNAL FUNCTION
function [rawSignal]=RecordSignal(sampleRate,duration)
%sampleRate= scalar, Hz
%duration=scalar, seconds

T = sampleRate*duration;
t = (1:T)/sampleRate;
rawSignal = sin(10*2*pi*t); %column vector of length sampleRate*duration

file='mod2_1.m';%define filename
save(file)

end


