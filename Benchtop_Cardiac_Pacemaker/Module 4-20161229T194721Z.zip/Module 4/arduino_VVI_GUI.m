function varargout = arduino_VVI_GUI(varargin)
% ARDUINO_VVI_GUI MATLAB code for arduino_VVI_GUI.fig
%      ARDUINO_VVI_GUI, by itself, creates a new ARDUINO_VVI_GUI or raises the existing
%      singleton*.
%
%      H = ARDUINO_VVI_GUI returns the handle to a new ARDUINO_VVI_GUI or the handle to
%      the existing singleton*.
%
%      ARDUINO_VVI_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ARDUINO_VVI_GUI.M with the given input arguments.
%
%      ARDUINO_VVI_GUI('Property','Value',...) creates a new ARDUINO_VVI_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before arduino_VVI_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to arduino_VVI_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help arduino_VVI_GUI

% Last Modified by GUIDE v2.5 26-Mar-2014 12:41:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @arduino_VVI_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @arduino_VVI_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before arduino_VVI_GUI is made visible.
function arduino_VVI_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to arduino_VVI_GUI (see VARARGIN)

% fclose(instrfind);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Serial Initialization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Define constant variables 
handles.comPort = 'COM27';                  % Specify COM port # to communicate with Arduino. This value can be found from the Arduino IDE

handles.readWindow = 5;                     % The width of the time window to show in live analog input display. Units in seconds

% Create serial port object communicating at 115200 BPS. The BaudRate must
% match the value set in the Arduino code.
handles.serialObject = serial(handles.comPort, 'BaudRate', 115200);

handles.serialObject.UserData.Vcc = 5;      % Store the Arduino power supply voltage, used for converting analog input data from counts to volts. See Arudino hardware webpage for the value specific to the board you are using.

% Attach timerfcn callback function. This function is used to check if a
% new sample rate or stimuluation rate has been entered through the GUI and
% sends a message to the Arduino if it has.
handles.serialObject.TimerFcn = @arduinoTimerFcn;

% Attach handles to various GUI uicontrols for use by the serial object's
% BytesAvailableFcn. The GUI's handles variable is not directly passed to this
% function. To make this function more memory efficient we only include the
% handles to the required uicontrols within the serialObject variable which is
% passed to the BytesAvailableFcn.

% Attached handle to plot axes.
handles.serialObject.UserData.axesHandle = handles.plot_axes;

% Attach handle to sample rate uicontrol.
handles.serialObject.UserData.sampleRateUicontrolHandle = handles.sample_rate;

% Attach handles to stim rate uicontrol.
handles.serialObject.UserData.stimRateUicontrolHandle = handles.stim_rate;

% Attach handle to toggle button uicontrol.
handles.serialObject.UserData.stopToggleButtonUicontrolHandle = handles.stop_acquisition;

% Attach default sample rate.
handles.serialObject.UserData.sampleRate = str2double( get(handles.sample_rate, 'String'));

% Attach default stim rate.
handles.serialObject.UserData.stimRate = str2double( get(handles.stim_rate, 'String'));

% Choose default command line output for arduino_VVI_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes arduino_VVI_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = arduino_VVI_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in start_acquisition.
function start_acquisition_Callback(hObject, eventdata, handles)
% This function is called to start data streaming from Arduino with live
% plotting of data on the GUI plot axes. A BytesAvailableFcn is attached to
% the serial object such that whenever information has been sent from the
% Arudino to the MATLAB computer, the function necessary to read and
% display that data on the MATLAB computer is executed.

% Attach BytesAvailableFcn callback function to the serial object.
handles.serialObject.BytesAvailableFcn = @readDataFromArduino;
handles.serialObject.BytesAvailableFcnMode = 'terminator';
handles.serialObject.Terminator = 'CR/LF';

% Read sample rate from GUI
sampleRate = str2double( get(handles.sample_rate, 'String')); % Samples per second sampled by the Arduino. Ensure the value of this variable matches the value of the same variable in the Arduino code

% Calculate number of samples in read window
numSamplesInReadWindow = handles.readWindow * sampleRate;

% Pre-allocate data vector. Must be global due to MATLAB inefficiencies.
% The first row of the varibale is used to store the sample time (time at
% which each analog input sample was acquired). The second row is used to
% store analog input samples.
global dataFromArduino;
dataFromArduino = zeros(4, numSamplesInReadWindow); %how many columns there are

% Store the number of times through the BytesAvailableFcn.
handles.serialObject.UserData.plotCounter = 1;

% Set a first time through flag.
handles.serialObject.UserData.firstTimeThrough = 1;

% Update the handles varibale
guidata(hObject, handles);

% Open connection to serial object, data streaming starts immediately after
% this function is executed and a byte is available on the serial port.
fopen(handles.serialObject);
disp('connection opened');


% This function reads available data from the Arduino
function readDataFromArduino(serialObject, eventData);
% Check if a full line of data is available
if (serialObject.BytesAvailable < 8)
    return;
end

% Read Data from Arduino. The first integer read is the sample time while
% the second integer read is the analog input sample. Additional values
% can be added here
stringData = fgets(serialObject);
tempData = sscanf(stringData, '%u %u %u %u');

% Error checking to ensure a full line is read from the Arduino. If
% additional samples are read the length which is checked here must be
% increased.
if (length(tempData) ~= 4);
    disp('length of tempData is not equal to 4');
    disp(stringData);
    disp(tempData);
    serialObject.BytesAvailable;
    return;
end

% Scale data accordingly to the proper units of time and voltage. See
% Arduino hardware manual for explanation of unit conversion from counts to
% volts
tempData = [(tempData(1) / 1e6) (tempData(2) / 1024 * serialObject.UserData.Vcc) (tempData(3) / 1024 * serialObject.UserData.Vcc) (tempData(4) / 1024 * serialObject.UserData.Vcc)];%all voltages and timesteps are accounted for

% Add data to ring buffer.
global dataFromArduino;
counter = mod(serialObject.UserData.plotCounter, length(dataFromArduino)) + 1;
dataFromArduino(:, counter) = tempData';

% Plot data (plot in chunks of 50 since plotting takes ~samplerate ampount of time!)
% Plot data (plot in chunks of 50 since plotting takes ~samplerate amount of time!)
if (0 == mod(serialObject.UserData.plotCounter, 50))
    plot(serialObject.UserData.axesHandle, [dataFromArduino(1, counter + 1 : end) dataFromArduino(1, 1 : counter)],...
        [dataFromArduino(2, counter + 1 : end) dataFromArduino(2, 1 : counter)],...
        [dataFromArduino(1, counter + 1 : end) dataFromArduino(1, 1 : counter)],...
        [dataFromArduino(3, counter + 1 : end) dataFromArduino(3, 1 : counter)],...
        [dataFromArduino(1, counter + 1 : end) dataFromArduino(1, 1 : counter)],...
        [dataFromArduino(4, counter + 1 : end) dataFromArduino(4, 1 : counter)]);
    axis(serialObject.UserData.axesHandle, 'tight');
    drawnow;
end

% Update number of times through BytesAvailableFcn counter.
serialObject.UserData.plotCounter = serialObject.UserData.plotCounter + 1;

% This function is used to check if a new sample rate or stimuluation rate 
% has been entered through the GUI and sends a message to the Arduino if it has.
function arduinoTimerFcn(serialObject, eventData)
% Check if stop toggle button has been pressed. If it has, stop data
% streaming.
if (1 == get(serialObject.UserData.stopToggleButtonUicontrolHandle, 'Value'))
    fclose(serialObject);
    
    % Save currently stored data.
    global dataFromArduino;
    save('data_from_ArduinoSIMUL2.mat', 'dataFromArduino');
    disp('data saved!');
    
    % Remove BytesAvailableFcn
    serialObject.BytesAvailableFcn = '';
    
    % Reset stop button.
    set(serialObject.UserData.stopToggleButtonUicontrolHandle, 'Value', 0);
end

% Check if sample rate has been updated, if it has, update
newSampleRate = str2double( get(serialObject.UserData.sampleRateUicontrolHandle, 'String'));
if (newSampleRate ~= serialObject.UserData.sampleRate)
   serialObject.UserData.sampleRate = newSampleRate;
   
   fprintf(serialObject, '1 %3.3f', newSampleRate);
end

% Check if stim rate has been updated, if it has, update
newStimRate = str2double( get(serialObject.UserData.stimRateUicontrolHandle, 'String'));
if (newStimRate ~= serialObject.UserData.stimRate)
   serialObject.UserData.stimRate = newStimRate;
   
   fprintf(serialObject, '2 %3.3f', newStimRate);
end